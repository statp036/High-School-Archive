
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;
// protypes
void declare_war(string su_type[4], string deck_rank[13]);
void shuffle_cards();
void shuffle_cards2();
void the_war(string su_type_en[4], string deck_rank_en[13]);
bool true_winner();
// global variables
int num = 26;
int num2 =26;
int pilenum1=0;
int pilenum2=0;
int handp1[52] = {};
int handp2[52] = {};
int pile1[52]  = {};
int pile2[52]  = {};

//Justin Jiang war project finish at 3-23-18
int main(){
  srand(time(0));
  string suite[4] = {"Spades", "Hearts", "Clubs", "Diamonds"}; // create suites
  string num_rank[13] = {"Two", "Three","Four","Five","Six","Seven","Eight","Nine","Ten","King", "Queen", "Jack", "Ace"}; // create rank
  int orig_deck[52];
   for(int i = 0; i< 52; i++) // create all cards
   {
     orig_deck[i] = i;
   } 	
  int temp40;
  int temp42;
  int num43;
  for(int i = 0; i<52; i++) // shuffle the deck
  {
  	temp40 = orig_deck[i];
  	num43 = rand()%52;
  	temp42 = orig_deck[num43];
  	orig_deck[num43] = temp40;
  	orig_deck[i] = temp42;
  }  
  for(int i =0; i<26; i++){  // split deck
	handp1[i] = orig_deck[i];
  }
  for(int i =0; i<26; i++){
	handp2[i] = orig_deck[i+26]; 
  }
  while(true_winner() == false) //  game won't end until one of the cpus win
  {
  	if(num == 0){  // shuffle if cpu1's deck ran out of cards
    num = pilenum1;
    shuffle_cards();
    pilenum1 = 0;
     }
  	if(num2 == 0){   // shuffle if cpu2's deck ran out of cards
    num2 = pilenum2;
    shuffle_cards2();
    pilenum2 = 0;
     }     
    declare_war(suite, num_rank);  //  cpus reveal their top card
  }
}

void declare_war(string su_type[4], string deck_rank[13])
{
  // if cpu1 has the greater card
  if((handp1[num-1])%13 > (handp2[num2-1])%13)
  {
    int suite_num = handp1[num-1]/13;
    int suite_num2 = handp2[num2-1]/13;
    int deck_num = handp1[num -1]%13;
    int deck_num2 = handp2[num2-1]%13;
    cout << su_type[suite_num] << " of " << deck_rank[deck_num] << " vs " << su_type[suite_num2] << " of " << deck_rank[deck_num2] << endl;
    cout << "cpu1 wins duel" << endl; // prit out cpu1 won the duel
    pilenum1 = pilenum1 + 2;
    pile1[pilenum1-1] = handp1[num-1];   // put the card's in cpu2's pile
    pile1[pilenum1-2] = handp2[num2-1];    
    num = num - 1;
    num2 = num2 -1;
  }
  // if cpu2 card rank is greater
  if((handp2[num2-1])%13 > (handp1[num-1])%13)
  {
    int suite_num3 = handp1[num-1]/13;
    int suite_num4 = handp2[num2-1]/13; 
    int deck_num3 = handp1[num -1]%13;
    int deck_num4 = handp2[num2-1]%13;    
    cout << su_type[suite_num3] << " of " << deck_rank[deck_num3] << " vs " << su_type[suite_num4] << " of " << deck_rank[deck_num4] << endl;
    cout << "cpu2 wins duel" << endl; // print out cpu2 won the duel
    pilenum2 = pilenum2 + 2;
    pile2[pilenum2-1] = handp1[num-1];    // put the card's in cpu2's pile
    pile2[pilenum2-2] = handp2[num2-1]; // 
    num = num - 1;
    num2 = num2 -1;
  }
  // if both ranks are equal
  if((handp1[num-1])%13 == (handp2[num2-1])%13)
  {
    int suite_num5 = handp1[num-1]/13;
    int suite_num6 = handp2[num2-1]/13;  
    int deck_num5 = handp1[num -1]%13;
    int deck_num6 = handp2[num2-1]%13;      
    cout << su_type[suite_num5] << " of " << deck_rank[deck_num5] << " vs " << su_type[suite_num6] << " of " << deck_rank[deck_num6] << endl;
    cout << "---- I DECLARE WAR! ----" << endl; // both cpu declare war
    the_war(su_type, deck_rank); // continue declare war
  }
}

// shuffles the crads for cpu1
void shuffle_cards()
{
  int temp;
  int temp2;
  int num3;
  for(int i = 0; i<pilenum1; i++)
  {
  	temp = pile1[i];
  	num3 = rand()%pilenum1;
  	temp2 = pile1[num3];
  	pile1[num3] = temp;
  	pile1[i] = temp2;
  }
  // change card placement ranks
  for(int i=0; i<pilenum1; i++)
  {
    handp1[i] = pile1[i];
  }
}

// shuffles the crads for cpu2
void shuffle_cards2()
{
  int temp;
  int temp2;
  int num3;
  for(int i = 0; i<pilenum2; i++)
  {
  	temp = pile2[i];
  	num3 = rand()%pilenum2;
  	temp2 = pile2[num3];
  	pile2[num3] = temp;
  	pile2[i] = temp2;
  }
  // change card placement ranks
  for(int i=0; i<pilenum2; i++)
  {
    handp2[i] = pile2[i];
  }
}

void the_war(string su_type_en[4], string deck_rank_en[13])
{
    int warhold[10];  // create an array to pile up the cards during war
    warhold[0] = handp1[num-1]; //  cpu1 put the crd on the war pile
    warhold[1] = handp2[num2-1]; // cpu2 put the card on the war pile
    num = num-1;
    num2 = num2 -1;
    // cpu1 puts the first 4 cards of his deck to the war pile
    for(int i=2; i<6; i++)
    {
  	  if(num == 0){  // shuffle if cpu1's deck ran out of cards
      num = pilenum1;
      shuffle_cards();
      pilenum1 = 0;
     }
      warhold[i] = handp1[num-1];
      num = num - 1;
    }
    // cpu2 puts first 4 cards in the war pile
    for(int j=6; j<10; j++)
    {
  	   if(num2 ==0){   // shuffle if cpu2's deck ran out of cards
       num2 = pilenum2;
       shuffle_cards2();
       pilenum2 = 0;
     }  
      warhold[j] = handp2[num2-1];
      num2 = num2 -1;
    }    
    // sees which of the fourh card ranks are greater
    // sees if cpu1 card hs the higher rank
    if(warhold[2]%13 > warhold[9]%13)
    {
     int suite_num7 = warhold[2]/13;
     int suite_num8 = warhold[9]/13;
     int deck_num7 = warhold[2]%13;
     int deck_num8 = warhold[9]%13;  
     cout << su_type_en[suite_num7] << " of " << deck_rank_en[deck_num7] << " vs " << su_type_en[suite_num8] << " of " << deck_rank_en[deck_num8] << endl;
     cout << "cpu1 wins the war" << endl;  // print out cpu 1 won the war
     pilenum1 = pilenum1 + 10;
      for(int i = 0; i<10; i++)   // put the cards from war pile to cpu1's pile
      {
        pile1[pilenum1-i-1] = warhold[i];
      }     
    }
    // sees if cpu2 card rank is greater
    if(warhold[9]%13> warhold[2]%13)
    {
     int suite_num9 = warhold[2]/13;
     int suite_num10 = warhold[9]/13;
     int deck_num9 = warhold[2]%13;
     int deck_num10 = warhold[9]%13; 
     cout << su_type_en[suite_num9] << " of " << deck_rank_en[deck_num9] << " vs " << su_type_en[suite_num10] << " of " << deck_rank_en[deck_num10] << endl;
     cout << "cpu2 wins the war" << endl; // print out cpu2 won the war
     pilenum2 = pilenum2 + 10;
      for(int i =0; i< 10; i++) // put the cards from war pile to cpu2's pile
      {
        pile2[pilenum2-i-1] = warhold[i];
      }
    }    
}

// see which cpu won
bool true_winner()
{
  if(num + pilenum1>=52){
    cout << "cpu1 wins" << endl;
    return true;
  }
  if(num2 + pilenum2 >= 52)  {
    cout << "cpu2 wins" << endl;
    return true;
  }
  return false;
}