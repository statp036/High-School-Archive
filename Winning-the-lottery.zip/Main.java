import java.util.Scanner;

class Main{
  public static void main(String[] args) {
    // Justin Jiang Exercises 3.15
    char unique = 'y';
    int powerball = 0;
    int accurate = 0;
    int[] lott_num = new int[6];
    int[] my_lott_num = new int[6];
    Scanner input = new Scanner(System.in);
    //creates numbers
     while(unique == 'y'){
       // create 5 random lottery numbers
       for(int i = 0; i <5; i++){
          lott_num[i] = (int)(Math.random()*100)%69 + 1; 
       }//
       lott_num[5] = (int)(Math.random()*100)%26 + 1; // create power ball number
       int non_unique = 0; // if unique number > 0, the lottery numbers aren't unique
       // check if lottery numbers are unique
       for(int i = 0; i<6;i++){
          for(int j = 1; j<i;j++){
             if(lott_num[i]==lott_num[j]){
               non_unique+=1;
             }
          }
       }
       //leave while loop if all lottery numbers are unique
       if(non_unique == 0){
          unique = 'n';   
       }
     }
    
     //tell user to enter their lottery number
     for(int k = 0; k < 5; k++){
       System.out.println("Enter a unique lottery number (1-69)");
       my_lott_num[k] = input.nextInt();
     }
     //user inputs powerball number
     System.out.println("Enter a unique powerball number (1-26)");
     my_lott_num[5] = input.nextInt();
    
     //check if user numbers are matching with lottery number
     for(int i = 0; i<5; i++){
         for(int j = 0; j < 5; j++){
            if(lott_num[i] == my_lott_num[j]){
               accurate +=1;                  
            }
         }
     }
     // check if user guess powerball number
     if(lott_num[5] == my_lott_num[5]){
       powerball = 1;
     } 
    
     //check users result
     if(accurate == 5 && powerball == 1){
       System.out.println("You guess all the numbers right. You won first place.($10,000)");
     }
     else if (accurate == 5 && powerball == 0){
       System.out.println("You guess 5 numbers right but not the powerball. You won second place.($3,000)");
     }
     else if(accurate == 4 && powerball == 1){
       System.out.println("You got 4 numbers right and the powerball. You won third place.($1,000)");
     } 
    
     // print the lottery numbers
     for(int i = 0; i<6; i++){
       System.out.print(lott_num[i] + " ");
     }
     System.out.print(":lottery number\n");
    
     //print user's lottery number
     for(int i = 0; i<6; i++){
       System.out.print(my_lott_num[i] + " ");
     }
     System.out.print(":your lottery number");     
  }
}