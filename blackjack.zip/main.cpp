#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

string suite[4] = {"S", "H", "C", "D"}; // create suites
string num_rank[13] = {"2","3","4","5","6","7","8","9","10","K", "Q", "J", "A"}; // create rank
int orig_deck[52];
int player_score = 0;
int dealer_score = 0;
int ace_holder = 0;
bool no_more_pls();
void shuffle_cards();
void deal_cards();
bool forever_hitting(char user_anss, int total_sum);
int card_sum(int pile[20], int limit);
void print_cards(int p_pile[20]);

int main(){
  srand(time(0));
  cout << "Welcome to the game of blackjack" << endl; // introduce player
   for(int i = 0; i< 52; i++) // create all cards
   {
     orig_deck[i] = i;
   }   
   do{
	 shuffle_cards(); // shuffle cards
	 deal_cards(); // start dealing
  }
  while(no_more_pls() == true);
}

bool no_more_pls()  
{
  char user_input;
  cout << "Want to play again? [Y/N] \nAnswer: ";
  cin >> user_input; // ask if player wants to play again
  if(user_input == 'n' || user_input == 'N'){ // if player says no
    cout << "Here is the final score" << endl; 
    cout << "Player:Dealer" << player_score << ":" << dealer_score << endl; // show score
    return false;
  }
  else{
    cout << "Lets continue" << endl; // continue game
    return true;
  }
}

void shuffle_cards()  // shuffle deck by using a insert function
{
  int temp, temp2, num;
  for(int i = 0; i<52; i++)
  {
  	temp = orig_deck[i];
  	num = rand()%52;
  	temp2 = orig_deck[num];
  	orig_deck[num] = temp;
  	orig_deck[i] = temp2;
  }
}

void deal_cards(){
  int player_pile[20];
  int dealer_pile[20]; 
  int player_sum = 0;
  int dealer_sum = 0;
  int card_token = 1;
  int limiter = 20;
  char user_ans;
  for(int i = 0; i<2; i++){
  player_pile[i] = orig_deck[52-card_token]; // give player two cards
  card_token++;
  }
  for(int i = 2; i<20; i++){
  player_pile[i] = 60;    // fill array with 60s
  }  
  player_sum = card_sum(player_pile,limiter);  // add value of cards
  print_cards(player_pile); // print player's cards
  ace_holder = 0;   // reset the ace 
  for(int j = 0; j<2; j++){
  dealer_pile[j] = orig_deck[52-card_token]; // give cards to dealer
  card_token++;
  }
  for(int j = 2; j<20; j++){ // fill array with 60s
  dealer_pile[j] = 60;
  } 
  dealer_sum = card_sum(dealer_pile,limiter); // add value of the dealer cards
  cout << "vs" << endl;
  print_cards(dealer_pile); // print dealer cards
  ace_holder = 0;
  cout << "Player total: " << player_sum << " vs Dealer total: " << dealer_sum << endl;
  dealer_sum = 0; // reset sum
  int player_deal_cards = 2;
  int dealer_deal_cards = 2;
  do{
    cout << "Hit or Stand(H/S): ";
    cin >> user_ans;cout<< endl;
    if(user_ans == 'H' || user_ans =='h')
    {
      player_pile[player_deal_cards] = orig_deck[52-card_token];  // add a card
      player_sum = card_sum(player_pile, limiter); // add value
      card_token++;
      player_deal_cards++;
      print_cards(player_pile); // print player cards
      cout << "Your total: " << player_sum << endl;
    }
  }while(forever_hitting(user_ans, player_sum) == true);
  ace_holder = 0;
  if(player_sum > 21){
    cout << "Busted! Your total sum was over 21" << endl;//tell  player value to high
    dealer_score ++;
    return;
  }
  while(dealer_sum >= 17){ // stop when dealer hits 17 or better
      dealer_pile[dealer_deal_cards] = orig_deck[52-card_token]; // dealer takes a card
      card_token++;    
      dealer_deal_cards++;
      dealer_sum = card_sum(dealer_pile,limiter);      
  }
  print_cards(dealer_pile);// print dealers cards
  cout << "Dealer total: " << dealer_sum << endl; // says the dealer total
  ace_holder = 0;
  if(dealer_sum >= 17){
    cout << "Dealer hit over 21 you win" << endl; // say dealer hit too much
    player_score ++;
    return;
  }
  if(player_sum > dealer_sum){ // say player won
    cout << "Dealer cards" << endl; 
    cout << "You win" << endl;
    player_score++;
  }
  if(player_sum < dealer_sum){
    cout << "Dealer wins" << endl;// say dealer won
    dealer_score ++;
  }
  if(player_sum == dealer_sum){
    cout << "Push! It's a draw" << endl; // say its a draw
  }
}

bool forever_hitting(char user_anss, int total_sum){
  if(user_anss == 's' || user_anss == 'S'){ // end hit if player says stand
    return false;
  }
  if(total_sum > 21){ // end hit if value over 21
    return false;
  }
  return true;
}

int card_sum(int pile[20], int limit){ // add total value of cards
 int sum = 0;
 for(int i = 0; i<limit; i++){
   if(pile[i] == 60){ // end adding when the next value is 60
      break;
   }
   else if(pile[i]%13 == 9){ // if king adds 10
     sum = sum + 10;
   }
   else if(pile[i]%13 == 10){// if queen adds 10
     sum = sum + 10;
   }        
   else if(pile[i]%13 == 11){// if jack adds 10
     sum = sum + 10;
   }        
   else if(pile[i]%13 == 12){ // if ace cpu stores the amont of ace
     ace_holder++;
   }
   else{
      sum = sum + pile[i]%13+2;
   }
 }
 if(ace_holder > 0){ // see if there's a ace in the pile
   for(int j=0; j< ace_holder; j++){
     if(sum + 11 > 21){
       sum = sum + 1; // add 11 if value wont hit over 21
     }
     else{
       sum = sum +11;
     }
   }
 }
 return sum;
}

void print_cards(int p_pile[20]){ // print a physical card
  for(int i = 0; i< 20; i++){
    if(p_pile[i] != 60){
      cout << "========  ";
    }
    else{
      break;
    }    
  }
  cout << endl;
  for(int i = 0; i< 20; i++){
  if(p_pile[i] != 60){  
  cout << "|" << num_rank[p_pile[i]%13] << "    |   "; // put rank on a corner
   }
     else{
      break;
    }  
  }
  cout << endl;
  for(int i = 0; i< 20; i++){
    if(p_pile[i] != 60){
    cout << "|  " << suite[p_pile[i]/13] << "  |   ";// put suite on the center
    }
    else{
      break;
    }    
  }
  cout << endl;
  for(int i = 0; i< 20; i++){
    if(p_pile[i] != 60){
    cout << "|   " << num_rank[p_pile[i]%13] << " |   "; // put a rank on the corner
    }
    else{
      break;
    }    
  }  
  cout << endl;
  for(int i = 0; i< 20; i++){
    if(p_pile[i] != 60){
      cout << "========  ";
    }
    else{
      break;
    }
  }
  cout << endl;
}