#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>
using namespace std;

//ma deck of cards
int main() {
  srand(time(0));
  string deck[] = {"Hearts", "Spades", "Clubs", "Diamonds"};
  string num_rank[] = {"Two", "Three","Four","Five","Six","Seven","Eight","Nine","Ten","King", "Queen", "Jack", "Ace"};
  bool used_cards[52] = {};
  for(int i = 0; i<52; i++)
  {
  used_cards[i] = true;
  }
  int num;
  for(int j=0; j<52; j++)
  {
    do{
      num = rand()%52;
    }while(used_cards[num] == false);
    used_cards[num] = false;
    int rank = rand()%13;
    int suits = num/13;
    cout << deck[suits] << " of " << num_rank[rank] << endl;
  }
}